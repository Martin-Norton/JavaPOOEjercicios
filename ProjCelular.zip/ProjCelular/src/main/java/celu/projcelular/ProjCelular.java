package celu.projcelular;

import entiCelu.CeluEntidad;
import servicelu.ServiCelular;

public class ProjCelular {

    public static void main(String[] args) {
        int i, N=1;
        ServiCelular cel = new ServiCelular();
        CeluEntidad[] lisCel = new CeluEntidad[N];
        for(i=0; i<N; i++) {
           CeluEntidad ce = cel.CreaCelular();
           lisCel[i]=ce;
        }
        for(i=0; i<N; i++){
            int j=i+1;
            System.out.println("Celular Nro: "+j);
            System.out.println("Marca: "+lisCel[i].getMarca());
            System.out.println("Modelo: "+lisCel[i].getPrecio());
            System.out.println("Precio: "+lisCel[i].getMemoriaram());
            System.out.println("Almacenamiento: "+lisCel[i].getAlmacenamiento()); 
            System.out.println("Código: "+lisCel[i].getAuxiCodigo());
           
        } 
        
    }
}
