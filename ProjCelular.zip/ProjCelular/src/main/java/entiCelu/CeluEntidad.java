package entiCelu;

import java.util.Scanner;

public class CeluEntidad {

    private String marca, modelo, auxiCodigo;
    private int precio, memoriaram, almacenamiento;
    private int[] codigo = new int[7];
    Scanner lee = new Scanner(System.in, "ISO-8859-1").useDelimiter("\n");

    public CeluEntidad() {

    }

    public CeluEntidad(String marca, String modelo, int precio, int memoriaram, int almacenamiento, String auxiCodigo) {
        this.marca = marca;
        this.modelo = modelo;
        this.precio = precio;
        this.memoriaram = memoriaram;
        this.almacenamiento = almacenamiento;
        this.auxiCodigo = auxiCodigo;
    }

    public String getMarca() {
        return marca;
    }

    public void setMarca(String marca) {
        this.marca = marca;
    }

    public String getModelo() {
        return modelo;
    }

    public void setModelo(String modelo) {
        this.modelo = modelo;
    }

    public int getPrecio() {
        return precio;
    }

    public void setPrecio(int precio) {
        this.precio = precio;
    }

    public int getMemoriaram() {
        return memoriaram;
    }

    public void setMemoriaram(int memoriaram) {
        this.memoriaram = memoriaram;
    }

    public int getAlmacenamiento() {
        return almacenamiento;
    }

    public void setAlmacenamiento(int almacenamiento) {
        this.almacenamiento = almacenamiento;
    }

    public String getAuxiCodigo() {
        return auxiCodigo;
    }

    public void setAuxiCodigo(String auxiCodigo) {
        this.auxiCodigo = auxiCodigo;
    }

    public int[] getCodigo() {
        return codigo;
    }

    public void setCodigo(int[] codigo) {
        this.codigo = codigo;
    }

    public Scanner getLee() {
        return lee;
    }

    public void setLee(Scanner lee) {
        this.lee = lee;
    }

    public void CargaCodigo() {
        int j;
        auxiCodigo="";
        for (int i = 0; i < 7; i++) {
             j=i+1;
            System.out.println("Ingrese Código: " + j + " Sucesivamente hasta completar 7 dígitos");
            codigo[i] = lee.nextInt();
            
            auxiCodigo+=codigo[i];
        }
    }

}
