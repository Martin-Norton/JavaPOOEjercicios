package servicelu;

import entiCelu.CeluEntidad;
import java.util.Scanner;

public class ServiCelular {
    Scanner lee = new Scanner(System.in, "ISO-8859-1").useDelimiter("\n");
    public CeluEntidad CreaCelular() {
        
        CeluEntidad cel = new CeluEntidad();
        System.out.println("Ingrese Marca");
        cel.setMarca(lee.next());
        System.out.println("Ingrese Modelo");
        cel.setModelo(lee.next());
        System.out.println("Ingrese Precio");
        cel.setPrecio(lee.nextInt());
        System.out.println("Ingrese Memoria Ram");
        cel.setMemoriaram(lee.nextInt());
        System.out.println("Ingrese Almacenamiento");
        cel.setAlmacenamiento(lee.nextInt());
        cel.CargaCodigo();
        return cel;
    }
    
}
