
package service;

import entidad.Cafetera;
import java.util.Scanner;

public class ServiceCafetera {
    private Scanner leer = new Scanner(System.in);
        
    public Cafetera llenarCafetera(){
        System.out.println("Ingresar capacidad de la cafetera: ");
        int capacidadMaxima = leer.nextInt();
        int cantidadActual = capacidadMaxima;
        return new Cafetera(capacidadMaxima, cantidadActual);
    }
    
    public void servirTaza(Cafetera cafetera){
        System.out.println("Ingrese tamaño de la taza vacía");
        int taza = leer.nextInt();
        
        if (cafetera.getCantidadActual() >= taza) {
            cafetera.setCantidadActual(cafetera.getCantidadActual()-taza);
            System.out.println("Se llenó la taza");
        }else if (cafetera.getCantidadActual() < taza){
            taza = cafetera.getCantidadActual();
            cafetera.setCantidadActual(0);
            System.out.println("La taza se lleno hasta " + taza);
        }
    }
    
    public void vaciarCafetera(Cafetera cafetera){
        cafetera.setCantidadActual(0);
    }
    
    public void agregarCafe(Cafetera cafetera){
        System.out.println("Cuanto café desea agregar?");
        int agregar = leer.nextInt();
        
        while(agregar > (cafetera.getCapacidadMaxima()-cafetera.getCantidadActual())){
            System.out.println("La cantidad que desea ingresar, llena la capacidad máxima de la cafetera (" + cafetera.getCapacidadMaxima()+")");
            System.out.println("La cantidad actual es " + cafetera.getCantidadActual());
            System.out.println("Ingrese un nuevo valor a agregar");
            agregar = leer.nextInt();
        }
        cafetera.setCantidadActual(cafetera.getCantidadActual()+agregar);
        System.out.println("Se cargo la cafetera");
        System.out.println("Cantidad actual: " + cafetera.getCantidadActual());
    }
    
    public void mostrarCafetera(Cafetera cafetera){
        System.out.println("Cantidad actual: " + cafetera.getCantidadActual());
    }
    
}
