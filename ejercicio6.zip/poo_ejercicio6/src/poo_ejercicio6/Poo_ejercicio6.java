
package poo_ejercicio6;

import entidad.Cafetera;
import service.ServiceCafetera;


public class Poo_ejercicio6 {

    public static void main(String[] args) {
        ServiceCafetera sc = new ServiceCafetera();
        
        System.out.println("Cafetera 1");
        Cafetera c1 = sc.llenarCafetera();
        
        System.out.println("Cafetera 2");
        Cafetera c2 = sc.llenarCafetera();
        
        System.out.println("Sirve taza 1 usando cafetera 1");
        sc.servirTaza(c1);

        System.out.println("cantidad actual cafeteras");
        sc.mostrarCafetera(c1);
        sc.mostrarCafetera(c2);
        
        System.out.println("Vaciando cafeteras");
        sc.vaciarCafetera(c1);
        sc.vaciarCafetera(c2);
        
        System.out.println("cantidad actual cafeteras");
        sc.mostrarCafetera(c1);
        sc.mostrarCafetera(c2);
        
        System.out.println("Agregando Café a cafetera 1");
        sc.agregarCafe(c1);
        System.out.println("Agregando Café a cafetera 2");
        sc.agregarCafe(c2);
    }
    
}
